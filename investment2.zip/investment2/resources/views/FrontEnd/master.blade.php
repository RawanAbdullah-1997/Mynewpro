<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="description" content="jobguru | Job Board HTML Templates from Themescare">
      <meta name="keyword" content="Job, freelancer, employee, marketplace">
      <meta name="author" content="Themescare">
      <!-- Title -->
      <title>jobguru</title>
      <!-- Favicon -->
      <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon/favicon-32x32.png">
      <!--Bootstrap css-->
      <link rel="stylesheet" href="assets/css/bootstrap.css">
      <!--Font Awesome css-->
      <link rel="stylesheet" href="assets/css/font-awesome.min.css">
      <!--Magnific css-->
      <link rel="stylesheet" href="assets/css/magnific-popup.css">
      <!--Owl-Carousel css-->
      <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
      <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
      <!--Animate css-->
      <link rel="stylesheet" href="assets/css/animate.min.css">
      <!--Select2 css-->
      <link rel="stylesheet" href="assets/css/select2.min.css">
      <!--Slicknav css-->
      <link rel="stylesheet" href="assets/css/slicknav.min.css">
      <!--Bootstrap-Datepicker css-->
      <link rel="stylesheet" href="assets/css/bootstrap-datepicker.min.css">
      <!--Jquery UI css-->
      <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
      <!--Perfect-Scrollbar css-->
      <link rel="stylesheet" href="assets/css/perfect-scrollbar.min.css">
      <!--Site Main Style css-->
      <link rel="stylesheet" href="assets/css/style.css">
      <!--Responsive css-->
      <link rel="stylesheet" href="assets/css/responsive.css">
   </head>
   <body>
       
       
      <!-- Header Area Start -->
      <header class="jobguru-header-area stick-top forsticky">
         <div class="menu-animation">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-lg-2">
                     <div class="site-logo">
                        <a href="index.html">
                        <img src="assets/img/logo.png" alt="jobguru" class="non-stick-logo" />
                        <img src="assets/img/logo-2.png" alt="jobguru" class="stick-logo" />
                        </a>
                     </div>
                     <!-- Responsive Menu Start -->
                     <div class="jobguru-responsive-menu"></div>
                     <!-- Responsive Menu Start -->
                  </div>
                  <div class="col-lg-6">
                     <div class="header-menu">
                        <nav id="navigation">
                           <ul id="jobguru_navigation">
                              <li class="active has-children">
                                 <a href="#">home</a>
                                 <ul>
                                    <li><a href="index.html">Home 1</a></li>
                                    <li><a href="index-2.html">Home 2</a></li>
                                 </ul>
                              </li>
                              <li class=" has-children">
                                 <a href="#">for candidates</a>
                                 <ul>
                                    <li class="has-inner-child">
                                       <a href="#">browse jobs</a>
                                       <ul>
                                          <li><a href="browse-jobs.html">full page grid</a></li>
                                          <li><a href="job-grid-sidebar.html">grid sidebar</a></li>
                                          <li><a href="job-list-sidebar.html">list sidebar</a></li>
                                       </ul>
                                    </li>
                                    <li><a href="browse-categories.html">Browse Categories</a></li>
                                    <li><a href="browse-companies.html">browse companies</a></li>
                                    <li><a href="single-candidates.html">candidates details</a></li>
                                    <li><a href="submit-resume.html">submit resume</a></li>
                                    <li class="has-inner-child">
                                       <a href="#">candidate dashboard</a>
                                       <ul>
                                          <li><a href="candidate-dashboard.html">Candidate dashboard</a></li>
                                          <li><a href="candidate-profile.html">Candidate profile</a></li>
                                          <li><a href="message.html">messages</a></li>
                                          <li><a href="manage-jobs.html">manage jobs</a></li>
                                          <li><a href="candidate-earnings.html">earnings</a></li>
                                          <li><a href="change-password.html">change password</a></li>
                                       </ul>
                                    </li>
                                 </ul>
                              </li>
                              <li class="has-children">
                                 <a href="#">for employers</a>
                                 <ul>
                                    <li><a href="browse-candidates.html">Browse Candidates</a></li>
                                    <li><a href="single-company.html">company details</a></li>
                                    <li><a href="post-job.html">Post A job</a></li>
                                    <li class="has-inner-child">
                                       <a href="#">employer dashboard</a>
                                       <ul>
                                          <li><a href="employer-dashboard.html">employer dashboard</a></li>
                                          <li><a href="company-profile.html">company profile</a></li>
                                          <li><a href="message.html">messages</a></li>
                                          <li><a href="manage-candidates.html">manage candidates</a></li>
                                          <li><a href="transaction.html">transaction</a></li>
                                          <li><a href="change-password.html">change password</a></li>
                                       </ul>
                                    </li>
                                 </ul>
                              </li>
                              <li class="has-children">
                                 <a href="#">pages</a>
                                 <ul>
                                    <li><a href="about.html">About us</a></li>
                                    <li class="has-inner-child">
                                       <a href="#">blog</a>
                                       <ul>
                                          <li><a href="blog.html">blog</a></li>
                                          <li><a href="single-blog.html">single blog</a></li>
                                       </ul>
                                    </li>
                                    <li><a href="job-page.html">job page</a></li>
                                    <li><a href="login.html">login</a></li>
                                    <li><a href="register.html">register</a></li>
                                    <li><a href="contact.html">contact us</a></li>
                                 </ul>
                              </li>
                           </ul>
                        </nav>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="header-right-menu">
                        <ul>
                           <li><a href="post-job.html" class="post-jobs">Post jobs</a></li>
                           <li><a href="register.html"><i class="fa fa-user"></i>sign up</a></li>
                           <li><a href="login.html"><i class="fa fa-lock"></i>login</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- Header Area End -->
       
       
      <!-- Banner Area Start -->
      <section class="jobguru-banner-area">
         <div class="banner-slider owl-carousel">
            <div class="banner-single-slider slider-item-1">
               <div class="slider-offset"></div>
            </div>
            <div class="banner-single-slider slider-item-2">
               <div class="slider-offset"></div>
            </div>
         </div>
         <div class="banner-text">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <div class="banner-search">
                        <h2>Hire expert freelancers.</h2>
                        <h4>We have 1542 job offers for you! </h4>
                        <form>
                           <div class="banner-form-box">
                              <div class="banner-form-input">
                                 <input type="text" placeholder="Job Title, Keywords, or Phrase">
                              </div>
                              <div class="banner-form-input">
                                 <input type="text" placeholder="City, State or ZIP">
                              </div>
                              <div class="banner-form-input">
                                 <select class="banner-select">
                                    <option selected>Select Sector</option>
                                    <option value="1">Design & multimedia</option>
                                    <option value="2">Programming & tech</option>
                                    <option value="3">Accounting/finance</option>
                                    <option value="4">content writting</option>
                                    <option value="5">Training</option>
                                    <option value="6">Digital Marketing</option>
                                 </select>
                              </div>
                              <div class="banner-form-input">
                                 <button type="submit"><i class="fa fa-search"></i></button>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Banner Area End -->
       
       
      <!-- Categories Area Start -->
      <section class="jobguru-categories-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="site-heading">
                     <h2>top Trending <span>Categories</span></h2>
                     <p>A better career is out there. We'll help you find it. We're your first step to becoming everything you want to be.</p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <a href="#" class="single-category-holder account_cat">
                     <div class="category-holder-icon">
                        <i class="fa fa-briefcase"></i>
                     </div>
                     <div class="category-holder-text">
                        <h3>Accounting & Finance</h3>
                     </div>
                     <img src="assets/img/account_cat.jpg" alt="category" />
                  </a>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <a href="#" class="single-category-holder design_cat">
                     <div class="category-holder-icon">
                        <i class="fa fa-pencil-square-o"></i>
                     </div>
                     <div class="category-holder-text">
                        <h3>Design, Art & Multimedia</h3>
                     </div>
                     <img src="assets/img/design_art.jpg" alt="category" />
                  </a>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <a href="#" class="single-category-holder restaurant_cat">
                     <div class="category-holder-icon">
                        <i class="fa fa-cutlery"></i>
                     </div>
                     <div class="category-holder-text">
                        <h3>Restaurant / Food Service</h3>
                     </div>
                     <img src="assets/img/restaurent.jpg" alt="category" />
                  </a>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <a href="#" class="single-category-holder tech_cat">
                     <div class="category-holder-icon">
                        <i class="fa fa-code"></i>
                     </div>
                     <div class="category-holder-text">
                        <h3>Programming & Tech</h3>
                     </div>
                     <img src="assets/img/programing_cat.jpeg" alt="category" />
                  </a>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <a href="#" class="single-category-holder data_cat">
                     <div class="category-holder-icon">
                        <i class="fa fa-bar-chart"></i>
                     </div>
                     <div class="category-holder-text">
                        <h3>Data Science & Analitycs</h3>
                     </div>
                     <img src="assets/img/data_cat.png" alt="category" />
                  </a>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <a href="#" class="single-category-holder writing_cat">
                     <div class="category-holder-icon">
                        <i class="fa fa-pencil"></i>
                     </div>
                     <div class="category-holder-text">
                        <h3>Writing / Translations</h3>
                     </div>
                     <img src="assets/img/writing_cat.jpg" alt="category" />
                  </a>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <a href="#" class="single-category-holder edu_cat">
                     <div class="category-holder-icon">
                        <i class="fa fa-graduation-cap"></i>
                     </div>
                     <div class="category-holder-text">
                        <h3>Education / Training</h3>
                     </div>
                     <img src="assets/img/edu_cat.jpg" alt="category" />
                  </a>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <a href="#" class="single-category-holder sale_cat">
                     <div class="category-holder-icon">
                        <i class="fa fa-bullhorn"></i>
                     </div>
                     <div class="category-holder-text">
                        <h3>sales / marketing</h3>
                     </div>
                     <img src="assets/img/sale_cat.png" alt="category" />
                  </a>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="load-more">
                     <a href="#" class="jobguru-btn">browse all categories</a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Categories Area End -->
       
       
      <!-- Inner Hire Area Start -->
      <section class="jobguru-inner-hire-area section_100">
         <div class="hire_circle"></div>
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="inner-hire-left">
                     <h3>Hire an employee</h3>
                     <p>placerat congue dui rhoncus sem et blandit .et consectetur Fusce nec nunc lobortis lorem ultrices facilisis. Ut dapibus placerat blandit nunc.congue dui rhoncus sem et blandit .et consectetur Fusce nec nunc lobortis lorem ultrices facilisis. Ut dapibus placerat blandi </p>
                     <a href="#" class="jobguru-btn-3">sign up as company</a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Inner Hire Area End -->
       
       
      <!-- Job Tab Area Start -->
      <section class="jobguru-job-tab-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="site-heading">
                     <h2>Companies & <span>job offers</span></h2>
                     <p>It's easy. Simply post a job you need completed and receive competitive bids from freelancers within minutes</p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class=" job-tab">
                     <ul class="nav nav-pills job-tab-switch" id="pills-tab" role="tablist">
                        <li class="nav-item">
                           <a class="nav-link active" id="pills-companies-tab" data-toggle="pill" href="#pills-companies" role="tab" aria-controls="pills-companies" aria-selected="true">top Companies</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" id="pills-job-tab" data-toggle="pill" href="#pills-job" role="tab" aria-controls="pills-job" aria-selected="false">job openning</a>
                        </li>
                     </ul>
                  </div>
                  <div class="tab-content" id="pills-tabContent">
                     <div class="tab-pane fade show active" id="pills-companies" role="tabpanel" aria-labelledby="pills-companies-tab">
                        <div class="top-company-tab">
                           <ul>
                              <li>
                                 <div class="top-company-list">
                                    <div class="company-list-logo">
                                       <a href="#">
                                       <img src="assets/img/company-logo-4.png" alt="company list 1" />
                                       </a>
                                    </div>
                                    <div class="company-list-details">
                                       <h3><a href="#">jamulai - consulting & finance Co.</a></h3>
                                       <p class="company-state"><i class="fa fa-map-marker"></i> Chicago, Michigan</p>
                                       <p class="open-icon"><i class="fa fa-briefcase"></i>32 open position</p>
                                       <p class="varify"><i class="fa fa-check"></i>Verified</p>
                                       <p class="rating-company">4.9</p>
                                    </div>
                                    <div class="company-list-btn">
                                       <a href="#" class="jobguru-btn">view profile</a>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="top-company-list">
                                    <div class="company-list-logo">
                                       <a href="#">
                                       <img src="assets/img/company-logo-2.png" alt="company list 1" />
                                       </a>
                                    </div>
                                    <div class="company-list-details">
                                       <h3><a href="#">Buildo - construction Co.</a></h3>
                                       <p class="company-state"><i class="fa fa-map-marker"></i> Chicago, Michigan</p>
                                       <p class="open-icon"><i class="fa fa-briefcase"></i>32 open position</p>
                                       <p class="varify"><i class="fa fa-check"></i>Verified</p>
                                       <p class="rating-company">4.2</p>
                                    </div>
                                    <div class="company-list-btn">
                                       <a href="#" class="jobguru-btn">view profile</a>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="top-company-list">
                                    <div class="company-list-logo">
                                       <a href="#">
                                       <img src="assets/img/company-logo-3.png" alt="company list 1" />
                                       </a>
                                    </div>
                                    <div class="company-list-details">
                                       <h3><a href="#">palms - school & college.</a></h3>
                                       <p class="company-state"><i class="fa fa-map-marker"></i> Chicago, Michigan</p>
                                       <p class="open-icon"><i class="fa fa-briefcase"></i>32 open position</p>
                                       <p class="varify"><i class="fa fa-check"></i>Verified</p>
                                       <p class="rating-company">4.6</p>
                                    </div>
                                    <div class="company-list-btn">
                                       <a href="#" class="jobguru-btn">view profile</a>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="top-company-list">
                                    <div class="company-list-logo">
                                       <a href="#">
                                       <img src="assets/img/company-logo-1.png" alt="company list 1" />
                                       </a>
                                    </div>
                                    <div class="company-list-details">
                                       <h3><a href="#">finance - consulting & business Co.</a></h3>
                                       <p class="company-state"><i class="fa fa-map-marker"></i> Chicago, Michigan</p>
                                       <p class="open-icon"><i class="fa fa-briefcase"></i>32 open position</p>
                                       <p class="varify"><i class="fa fa-check"></i>Verified</p>
                                       <p class="rating-company">4.9</p>
                                    </div>
                                    <div class="company-list-btn">
                                       <a href="#" class="jobguru-btn">view profile</a>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="tab-pane fade" id="pills-job" role="tabpanel" aria-labelledby="pills-job-tab">
                        <div class="top-company-tab">
                           <ul>
                              <li>
                                 <div class="top-company-list">
                                    <div class="company-list-logo">
                                       <a href="#">
                                       <img src="assets/img/company-logo-1.png" alt="company list 1" />
                                       </a>
                                    </div>
                                    <div class="company-list-details">
                                       <h3><a href="#">Regional Sales Manager</a></h3>
                                       <p class="company-state"><i class="fa fa-map-marker"></i> Chicago, Michigan</p>
                                       <p class="open-icon"><i class="fa fa-clock-o"></i>2 minutes ago</p>
                                       <p class="varify"><i class="fa fa-check"></i>Fixed price : $1200-$2000</p>
                                       <p class="rating-company">4.1</p>
                                    </div>
                                    <div class="company-list-btn">
                                       <a href="#" class="jobguru-btn">bid now</a>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="top-company-list">
                                    <div class="company-list-logo">
                                       <a href="#">
                                       <img src="assets/img/company-logo-4.png" alt="company list 1" />
                                       </a>
                                    </div>
                                    <div class="company-list-details">
                                       <h3><a href="#">C Developer (Senior) C .Net</a></h3>
                                       <p class="company-state"><i class="fa fa-map-marker"></i> Chicago, Michigan</p>
                                       <p class="open-icon"><i class="fa fa-clock-o"></i>2 minutes ago</p>
                                       <p class="varify"><i class="fa fa-check"></i>Fixed price : $800-$1200</p>
                                       <p class="rating-company">3.1</p>
                                    </div>
                                    <div class="company-list-btn">
                                       <a href="#" class="jobguru-btn">bid now</a>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="top-company-list">
                                    <div class="company-list-logo">
                                       <a href="#">
                                       <img src="assets/img/company-logo-3.png" alt="company list 1" />
                                       </a>
                                    </div>
                                    <div class="company-list-details">
                                       <h3><a href="#">Asst. Teacher</a></h3>
                                       <p class="company-state"><i class="fa fa-map-marker"></i> Chicago, Michigan</p>
                                       <p class="open-icon"><i class="fa fa-clock-o"></i>3 minutes ago</p>
                                       <p class="varify"><i class="fa fa-check"></i>Fixed price : $800-$1200</p>
                                       <p class="rating-company">4.3</p>
                                    </div>
                                    <div class="company-list-btn">
                                       <a href="#" class="jobguru-btn">bid now</a>
                                    </div>
                                 </div>
                              </li>
                              <li>
                                 <div class="top-company-list">
                                    <div class="company-list-logo">
                                       <a href="#">
                                       <img src="assets/img/company-logo-2.png" alt="company list 1" />
                                       </a>
                                    </div>
                                    <div class="company-list-details">
                                       <h3><a href="#">civil engineer</a></h3>
                                       <p class="company-state"><i class="fa fa-map-marker"></i> Chicago, Michigan</p>
                                       <p class="open-icon"><i class="fa fa-clock-o"></i>30 minutes ago</p>
                                       <p class="varify"><i class="fa fa-check"></i>Fixed price : $2000-$2500</p>
                                       <p class="rating-company">3.7</p>
                                    </div>
                                    <div class="company-list-btn">
                                       <a href="#" class="jobguru-btn">bid now</a>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="load-more">
                     <a href="#" class="jobguru-btn">browse more listing</a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Job Tab Area End -->
       
       
      <!-- Video Area Start -->
      <section class="jobguru-video-area section_100">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="video-container">
                     <h2>Hire experts freelancers today for <br> any job, any time.</h2>
                     <div class="video-btn">
                        <a class="popup-youtube" href="https://www.youtube.com/watch?v=k-R6AFn9-ek">
                        <i class="fa fa-play"></i>
                        how it works
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Video Area End -->
       
       
      <!-- How Works Area Start -->
      <section class="how-works-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="site-heading">
                     <h2>how it <span>works</span></h2>
                     <p>It's easy. Simply post a job you need completed and receive competitive bids from freelancers within minutes</p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-4">
                  <div class="how-works-box box-1">
                     <img src="assets/img/arrow-right-top.png" alt="works" />
                     <div class="works-box-icon">
                        <i class="fa fa-user"></i>
                     </div>
                     <div class="works-box-text">
                        <p>sign up</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="how-works-box box-2">
                     <img src="assets/img/arrow-right-bottom.png" alt="works" />
                     <div class="works-box-icon">
                        <i class="fa fa-gavel"></i>
                     </div>
                     <div class="works-box-text">
                        <p>post job</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="how-works-box box-3">
                     <div class="works-box-icon">
                        <i class="fa fa-thumbs-up"></i>
                     </div>
                     <div class="works-box-text">
                        <p>choose expert</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- How Works Area End -->
       
       
      <!-- Blog Area Start -->
      <section class="jobguru-blog-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="site-heading">
                     <h2>Recent From <span>Blog</span></h2>
                     <p>It's easy. Simply post a job you need completed and receive competitive bids from freelancers within minutes</p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-4 col-md-12">
                  <a href="#">
                     <div class="single-blog">
                        <div class="blog-image">
                           <img src="assets/img/blog-1.jpeg" alt="blog image" />
                           <p><span> 21</span> July</p>
                        </div>
                        <div class="blog-text">
                           <h3>If you're having trouble coming up with</h3>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-lg-4 col-md-12">
                  <a href="#">
                     <div class="single-blog">
                        <div class="blog-image">
                           <img src="assets/img/blog-2.jpeg" alt="blog image" />
                           <p><span> 21</span> July</p>
                        </div>
                        <div class="blog-text">
                           <h3>details about Apple’s new iPad Pro models</h3>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-lg-4 col-md-12">
                  <a href="#">
                     <div class="single-blog">
                        <div class="blog-image">
                           <img src="assets/img/blog-3.jpeg" alt="blog image" />
                           <p><span> 21</span> July</p>
                        </div>
                        <div class="blog-text">
                           <h3>what are those Steps to be a Successful developer</h3>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <!-- Blog Area End -->
       @include('FrontEnd.Blog')
       
      <!-- Footer Area Start -->
      @yield('footer');
      <!-- Footer Area End -->
       
       
      <!--Jquery js-->
      <script src="assets/js/jquery-3.0.0.min.js"></script>
      <!--Popper js-->
      <script src="assets/js/popper.min.js"></script>
      <!--Bootstrap js-->
      <script src="assets/js/bootstrap.min.js"></script>
      <!--Bootstrap Datepicker js-->
      <script src="assets/js/bootstrap-datepicker.min.js"></script>
      <!--Perfect Scrollbar js-->
      <script src="assets/js/jquery-perfect-scrollbar.min.js"></script>
      <!--Owl-Carousel js-->
      <script src="assets/js/owl.carousel.min.js"></script>
      <!--SlickNav js-->
      <script src="assets/js/jquery.slicknav.min.js"></script>
      <!--Magnific js-->
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <!--Select2 js-->
      <script src="assets/js/select2.min.js"></script>
      <!--jquery-ui js-->
      <script src="assets/js/jquery-ui.min.js"></script>
      <!--Main js-->
      <script src="assets/js/main.js"></script>
   </body>
</html>

